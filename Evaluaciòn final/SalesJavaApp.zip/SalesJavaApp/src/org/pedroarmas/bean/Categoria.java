package org.pedroarmas.bean;


public class Categoria {
   
    
}
